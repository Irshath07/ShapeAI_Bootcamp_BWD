import React from "react";

function Header(){
  return (
    <Header>
        <h1>ShapeAI Bootcamp</h1>
    </Header> 
  );
}

export default Header;