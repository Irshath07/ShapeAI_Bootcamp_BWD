import React from "react";

function Info() {
  return (
    <div className="note">
      <h1>javascript and React.js</h1>
      <p>a basic web dev React JS Bootcamp</p>
    </div>
  );
}

export default Info;